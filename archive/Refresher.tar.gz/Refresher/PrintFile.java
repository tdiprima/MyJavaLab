//: PrintFile.java
//////////////////////////////////////////////////

// Shorthand class for opening an output file
// for human-readable output.
import java.io.*;

public class PrintFile extends PrintStream 
{
	public PrintFile(File file) throws IOException 
	{
		this(file.getPath());
	}
	
	public PrintFile(String filename) throws IOException 
	{
		super(new BufferedOutputStream(new FileOutputStream(filename)));
	}

	/**
	 * Usage:
	 */
	public static void main(String[] args) 
	{
		PrintFile out1;

		try 
		{
			out1 = new PrintFile("C:\\TestFile.txt");
			out1.print("This is a test of the PrintFile class.");
			out1.close();
		}
		catch (IOException ex) 
		{
			ex.printStackTrace();
		}

	}
}
