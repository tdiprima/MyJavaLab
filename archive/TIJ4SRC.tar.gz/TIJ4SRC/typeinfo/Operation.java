//: typeinfo/Operation.java

public interface Operation {
  String description();
  void command();
} ///:~
